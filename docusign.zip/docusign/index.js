const express=require("express");
const path=require("path");
const bodyParser=require("body-parser");
const dotenv=require("dotenv");
const fs=require("fs");
const session=require("express-session");

dotenv.config();
const docusign=require("docusign-esign");
const app=express();
app.use(bodyParser.urlencoded({extended:true}));
app.use(session({
    secret:"pradeep",
    resave:true,
    saveUninitialized:true
}));
// app.get("/",(request,response)=>{
//     response.send("Hello World!");
// });

// app.post("/form",(request,response)=>{
//     console.log("received form data",request.body);
// response.send("received");
// });

// app.get("/",(request,response)=>{
//     response.sendFile(path.join(__dirname,"main.html"));
// });

app.post("/form",async(request,response)=>{
    await checkToken(request);
        
        let envelopesApi = getEnvelopeApi(request);
        
        // Make the envelope request body
        let envelope = makeEnvelope(request.body.name,request.body.email);
    
        // Call Envelopes::create API method
        // Exceptions will be caught by the calling function
        let results = await envelopesApi.createEnvelope(
            process.env.ACCOUNT_ID, {envelopeDefinition: envelope});
console.log("envelope results",results);

// Create the recipient view, the Signing Ceremony
let viewRequest = makeRecipientViewRequest(request.body.name,request.body.email);
// Call the CreateRecipientView API
// Exceptions will be caught by the calling function
results = await envelopesApi.createRecipientView(process.env.ACCOUNT_ID, results.envelopeId,
    {recipientViewRequest: viewRequest});

    console.log("view results",results);
  console.log({envelopeId: results.envelopeId, redirectUrl: results.url});
    console.log("received form data",request.body);

//response.send("received");

response.redirect(results.url);
});
function getEnvelopeApi(request){ 
    let dsApiClient = new docusign.ApiClient();
	    dsApiClient.setBasePath(process.env.BASE_PATH);
	    dsApiClient.addDefaultHeader('Authorization', 'Bearer ' + request.session.access_token);
	return new docusign.EnvelopesApi(dsApiClient);
}
function makeEnvelope(name,email){

    // Create the envelope definition
    let env = new docusign.EnvelopeDefinition();
    env.templateId = process.env.TEMPLATE_ID;

    // Create template role elements to connect the signer and cc recipients
    // to the template
    // We're setting the parameters via the object creation
    let signer1 = docusign.TemplateRole.constructFromObject({
        email: email,
        name: name,
        roleName: 'Applicant'});

        // Add the TemplateRole objects to the envelope object
    env.templateRoles = [signer1];
    env.status = "sent"; // We want the envelope to be sent

    return env;
}

function makeRecipientViewRequest(name,email,clientUserId) {
    // Data for this method
    // args.dsReturnUrl 
    // args.signerEmail 
    // args.signerName 
    // args.signerClientId
    // args.dsPingUrl 

    let viewRequest = new docusign.RecipientViewRequest();

    // Set the url where you want the recipient to go once they are done signing
    // should typically be a callback route somewhere in your app.
    // The query parameter is included as an example of how
    // to save/recover state information during the redirect to
    // the DocuSign signing ceremony. It's usually better to use
    // the session mechanism of your web framework. Query parameters
    // can be changed/spoofed very easily.
    viewRequest.returnUrl = "http://localhost:8000/success";

    // How has your app authenticated the user? In addition to your app's
    // authentication, you can include authenticate steps from DocuSign.
    // Eg, SMS authentication
    viewRequest.authenticationMethod = 'none';
    
    // Recipient information must match embedded recipient info
    // we used to create the envelope.
    viewRequest.email = email;
    viewRequest.userName = name;
    viewRequest.clientUserId =clientUserId;// process.env.CLIENT_USER_ID;

    // DocuSign recommends that you redirect to DocuSign for the
    // Signing Ceremony. There are multiple ways to save state.
    // To maintain your application's session, use the pingUrl
    // parameter. It causes the DocuSign Signing Ceremony web page
    // (not the DocuSign server) to send pings via AJAX to your
    // app,
 //   viewRequest.pingFrequency = 600; // seconds
    // NOTE: The pings will only be sent if the pingUrl is an https address
   // viewRequest.pingUrl = args.dsPingUrl; // optional setting

    return viewRequest
}

async function checkToken(request){ 
    if(request.session.access_token && Date.now()< request.session.expires_at){
    console.log("reusing access_token  ",request.session.access_token)
}
else { 
console.log("generating new acces token");
let dsApiClient = new docusign.ApiClient();
dsApiClient.setBasePath(process.env.BASE_PATH);
const results = await dsApiClient.requestJWTUserToken(
    process.env.INTEGRATION_KEY,
    process.env.USER_ID,
     "signature", 
      fs.readFileSync(path.join(__dirname,"private.key")), 
      3600);
console.log(results.body);
request.session.access_token=results.body.access_token;
request.session.expires_at=Date.now()+(results.body.expires_in-60)*1000;}
}

app.get("/",async (request,response)=>{
    response.sendFile(path.join(__dirname,"main.html"));
});

app.get("/success",(request,response)=>{
    response.send("Success");
})
app.listen(8000,()=>{
    console.log("server started 8000",process.env.USER_ID)
});

// https://account-d.docusign.com/oauth/auth?response_type=code &scope=signature%20impersonation&client_id=0dac0464-590c-4072-a2ae-24ca4eceb74f&redirect_uri=http://localhost:8000/